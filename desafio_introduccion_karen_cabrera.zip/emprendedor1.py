#Karen Cabrera 28-02-2024

p= int (input("Ingrese el precio de  suscripción: "))
u= int (input("Ingrese el número de  usuarios: "))
gt= int (input("Ingrese los gastos totales: "))

utilidades = print(f"las utilidades son: {(p*u)-gt}" )
